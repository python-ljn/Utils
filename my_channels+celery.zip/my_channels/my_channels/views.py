from django.shortcuts import render
from jianshu.models import Article
from jianshu.task import increase_views_task

def index(request):
    return render(request, 'index.html', locals())


def test(request):
    uuid = request.GET.get('uuid', '')
    res = Article.objects.get(uuid=uuid)
    result = increase_views_task.apply_async((res, ), task_id=uuid)

    return render(request, 'test.html', locals())