from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from Lib.request_jianshu import *
from jianshu.serializer import ArticleSerializer

from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
import json
# Create your views here.

from .models import Article


class PostDetailAPIView(APIView):

    def get(self, request, article_id, format=None):
        try:
            return_data = get_article_csrf_uuid(article_id)
            print(return_data, '1231')
            serializer = ArticleSerializer(data=return_data)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data, status=status.HTTP_201_CREATED)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        except AttributeError as e:
            return Response('该文章编号不存在, 请换个编号重试！', status=status.HTTP_400_BAD_REQUEST)


@csrf_exempt
def task(request):
    if request.method == 'POST':
        uuid = request.POST.get('uuid')
        add_count = request.POST.get('add_count')
        result = Article.objects.get(uuid=uuid)
        result.add_count = add_count
        result.save()
        return JsonResponse({
            'code': 201,
            'message': '',
            'data': result.uuid,
        })