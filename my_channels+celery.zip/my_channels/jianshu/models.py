from django.db import models

# Create your models here.


class Article(models.Model):
    add_count = models.IntegerField(verbose_name='增加数量', default=0)
    article_id = models.CharField(max_length=50, verbose_name='文章id')
    word_num = models.IntegerField(default=0, verbose_name='文章单词数量')
    views_count = models.IntegerField(default=0, verbose_name='阅读数量')
    csrf_token = models.CharField(max_length=256, verbose_name='csrf_token值')
    uuid = models.CharField(max_length=128, verbose_name='uuid数量')
    likes_count = models.IntegerField(default=0, verbose_name='喜欢数量')
    comments_count = models.IntegerField(default=0, verbose_name='评论数量')
    publish_time = models.DateTimeField(verbose_name='文章发表时间')
    is_complete = models.BooleanField(default=0, verbose_name='是否完成')
    objects = models.Manager()