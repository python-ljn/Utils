from channels import layers
from asgiref.sync import async_to_sync

from my_channels import celery_app
import json
import time
from .models import Article

from Lib.request_jianshu import *


@celery_app.task(bind=True)
def increase_views_task(self, data):

    generate = spider_num(data.add_count, data.article_id, data.csrf_token, data.uuid)
    layer = layers.get_channel_layer()
    start_time = time.time()
    try:
        for progress in generate:
            self.update_state(state='PROGRESS', meta={'exc': progress})
            async_to_sync(layer.group_send)(data.article_id, {
                "type": "chat_message",
                "message": json.dumps({
                    'status': 'PROGRESS', 'progress': progress
                })
            })
    except Exception as e:
        self.update_state(state='FAIL', meta={'exc': str(e)})
        async_to_sync(layer.group_send)(data.article_id, {
            "type": "chat_message",
            "message": json.dumps({
                'status': 'FAIL', 'progress': 0
            })
        })
        return 'FAIL {}'.format(e)
    else:
        async_to_sync(layer.group_send)(data.article_id, {
            "type": "chat_message",
            "message": json.dumps({
                'status': 'FINISH', 'progress': 1
            })
        })
        end_time = time.time()
        return 'FINISH 耗时{}s'.format(end_time - start_time)