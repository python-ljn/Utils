# coding: utf-8
from rest_framework import serializers
from .models import Article


class ArticleSerializer(serializers.Serializer):

    id = serializers.IntegerField(label='id', read_only=True)
    add_count = serializers.IntegerField(label='增加数量', default=0)
    article_id = serializers.CharField(max_length=50, label='文章id')
    word_num = serializers.IntegerField(label='文章单词数量', default=0)
    views_count = serializers.IntegerField(label='阅读数量', default=0)
    csrf_token = serializers.CharField(max_length=256, label='csrf_token')
    uuid = serializers.CharField(max_length=128, label='uuid')
    likes_count = serializers.IntegerField(default=0, label='喜欢的数量')
    comments_count = serializers.IntegerField(default=0, label='评论数量')
    publish_time = serializers.DateTimeField(label='发表时间')

    def create(self, validated_data):
        """
        根据提供的验证过的数据创建并返回一个article实例
        :param validated_data:
        :return:
        """
        print(validated_data, '99999999999')

        return Article.objects.create(**validated_data)

    def update(self, instance, validated_data):
        instance.id = validated_data.get('id', instance.id)
        instance.add_count = validated_data.get('add_count', instance.add_count)
        instance.article_id = validated_data.get('article_id', instance.article_id)
        instance.word_num = validated_data.get('word_num', instance.word_num)
        instance.views_count = validated_data.get('views_count', instance.views_count)
        instance.csrf_token = validated_data.get('csrf_token', instance.csrf_token)
        instance.uuid = validated_data.get('uuid', instance.uuid)
        instance.likes_count = validated_data.get('likes_count', instance.likes_count)
        instance.comments_count = validated_data.get('comments_count', instance.comments_count)
        instance.publish_time = validated_data.get('publish_time', instance.publish_time)

