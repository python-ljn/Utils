from django.urls import path
from django.conf.urls import url
from .views import *

app_name = 'jianshu'

urlpatterns = [
    url('^task/', task, name='task'),
    path('post/<str:article_id>/', PostDetailAPIView.as_view()),
    path('task/<str:article_id>/', PostDetailAPIView.as_view()),

]