import requests
import re
import datetime
from django.core.cache import cache

headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'zh-CN,zh;q=0.9',
    'Host': 'www.jianshu.com',
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36'
}

BASE_URL = 'https://www.jianshu.com/p/'


# post_num 文章编号
def get_article_csrf_uuid(post_num):
    return_data = {}
    res = requests.get(BASE_URL + post_num, headers=headers)
    content = res.text
    # csrf_token
    csrf_token = re.search('<meta name="csrf-token" content="(.*?)"', content).group(1)
    # uuid

    uuid = re.search('"uuid":"(.*?)"', content).group(1)
    # 文章字数
    word_num = re.search('<span class="wordage">.*?(\d+?)<', content).group(1)
    # 获取喜欢数量,
    views_count = re.search('views_count.*?(\d+?),', content).group(1)
    likes_count = re.search('likes_count.*?(\d+?),', content).group(1)
    comments_count = re.search('comments_count.*?(\d+?),', content).group(1)
    publish_time = re.search('<span class="publish-time">(.*?)<', content).group(1)
    print(content)
    print(word_num)
    return_data['csrf_token'] = csrf_token  # csrf_token
    return_data['uuid'] = uuid  # uuid
    return_data['word_num'] = word_num  # 文章字数
    return_data['views_count'] = views_count  # 阅读数量
    return_data['likes_count'] = likes_count  # 喜欢数量
    return_data['comments_count'] = comments_count  # 评论数量
    return_data['publish_time'] = datetime.datetime.strptime(publish_time.replace('.', '-'), '%Y-%m-%d %H:%M')  # 发布时间
    return_data['article_id'] = post_num  # 文章编号
    return_data['add_count'] = 0  # 增加数量
    return return_data


# 模拟用户阅读量
def spider_num(increase_count, post_num, csrf_token, uuid):
    data = {
        'uuid': uuid
    }
    for x in range(increase_count):
        head_copy = headers.copy()
        # 格式化 f""
        url = f'https://www.jianshu.com/notes/{post_num}/mark_viewed.json'
        head_copy['X-CSRF-Token'] = csrf_token
        head_copy['referer'] = BASE_URL + post_num

        resp = requests.post(url, headers=head_copy, data=data)
        if not 200 <= resp.status_code < 300:
            raise ValueError('解析错误, 请检查参数是否正确!')
        yield x / increase_count


if __name__ == '__main__':
    result = get_article_csrf_uuid('618069f2a4d7')
    print(result)
    a = spider_num(increase_count=500, post_num=result['post_num'], csrf_token=result['csrf_token'], uuid=result['uuid'])
    for x in a:
        print(x)
    print(a, 11111111111)